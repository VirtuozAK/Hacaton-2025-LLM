from logging import exception
from openai import OpenAI
import requests
from secret import API_KEY,BASE_URL,URL_TEST,QUESTION_TEST
from tqdm import tqdm
from bs4 import BeautifulSoup
import re
from urllib.parse import urljoin

client = OpenAI(
    api_key=API_KEY,
    base_url=BASE_URL,
)

# === Вызов OpenAI Chat Completion ===
def call_llm(prompt, model="gemini-2.0-flash-001"):
    response = client.chat.completions.create(
        model=model,
        messages=[
            {"role": "system", "content": "Ты помощник, который отвечает кратко и по делу. Если ты не можешь найти информацию, то ты отвечаешь: 'Нет информации.'"},
            {"role": "user", "content": prompt}
        ],
        max_tokens=500
    )
    return response.choices[0].message.content.strip()

# === Парсинг всех вложенных ссылок с сайта ===
def get_all_links(url):
    try:
        response = requests.get(url)
        response.raise_for_status()
        soup = BeautifulSoup(response.text, 'html.parser')
        links = []
        pattern = url + r"#."
        for link in soup.find_all('a', href=True):
            href = link['href']
            absolute_url = urljoin(url, href)
            if absolute_url.startswith(('http://', 'https://')):
                if ((absolute_url != url) and len(re.findall(pattern, absolute_url))==0):
                    links.append(absolute_url)
        unique_links = list(set(links))
    except requests.exceptions.RequestException as e: pass
    return unique_links

# === Парсинг таблиц с сайта ===
def parse_html_table(url):
    response = requests.get(url)
    response.raise_for_status()
    soup = BeautifulSoup(response.text, 'html.parser')
    tables = soup.find_all('table')

    rows = []
    for table in tables:
        for row in table.find_all('tr')[1:]:  # Пропускаем заголовок
            cells = row.find_all(['td', 'th'])
            row_data = [cell.get_text(strip=True) for cell in cells]
            if row_data:  # Игнорируем пустые строки
                rows.append(row_data)
    return rows

# === Очистка текста и перевод его в более читабельный вид ===
def clean_text(text):
    text = re.sub(r'\s+', ' ', text)
    text = text.strip()
    return text

# === Разбиение текста на абзацы ===
def split_into_paragraphs(text, max_line_length=80):
    sentences = re.split(r'(?<=[.!?])\s+', text)
    paragraphs = []
    current_paragraph = []
    current_length = 0

    for sentence in sentences:
        if current_length + len(sentence) <= max_line_length:
            current_paragraph.append(sentence)
            current_length += len(sentence)
        else:
            paragraphs.append(' '.join(current_paragraph))
            current_paragraph = [sentence]
            current_length = len(sentence)

    if current_paragraph:
        paragraphs.append(' '.join(current_paragraph))

    return '\n\n'.join(paragraphs)

# === Загрузка и очистка HTML ===
def fetch_html_text(url):
    headers = {
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/119.0.0.0 Safari/537.36'
    }
    text = requests.get(url, headers=headers)
    soup = BeautifulSoup(text.text, 'html.parser')
    for element in soup(['script', 'style', 'nav', 'footer', 'head', 'iframe']):
        element.decompose()
    raw_text = soup.get_text()

    cleaned_text = clean_text(raw_text)
    formatted_text = split_into_paragraphs(cleaned_text)
    return formatted_text

# === Краткое содержание ===
def summarize_text(text):
    prompt = f"Составь краткое содержание текста: \n\n{text[:99999999]}"
    return call_llm(prompt)

# === Ответ на вопросы ===
def answer_questions(summary, questions):
    answers = []
    for q in tqdm(questions, desc="Обработка вопросов"):
        prompt = f"На основе следующего краткого содержания:\n{summary}\n\nОтветь на вопрос: {q}"
        answer = call_llm(prompt)
        answers.append((q, answer))
    return answers

# === Использование ===
if __name__ == "__main__":
    for site in URL_TEST:
        print(f"\n=== SITE: {site} ===")
        html_text = fetch_html_text(site)
        summary = summarize_text(html_text)

        try:
            for i in get_all_links(site):
                html_text_sites = fetch_html_text(i)
                summary += summarize_text(html_text_sites)
        except Exception as e: pass
        
        tables_sites = parse_html_table(site)
        for table in tables_sites:
            help_row = ""
            for i in table:
                help_row += i + " "
            summary += help_row + "\n"

        print ("Summary:", summary)
        answers = answer_questions(summary, QUESTION_TEST)
        print("\n=== Ответы ===")
        for _, a in answers:
            print(f"{a}\n")